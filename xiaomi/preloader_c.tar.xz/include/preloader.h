#ifndef PRELOADER_H
#define PRELOADER_H

#include <stdint.h>
#include <stddef.h>

// SoC info
#define SOC_MT6877    0x00000D03
#define SOC_MT6877_ALT 0x00000D04

// Memory map
#define PRELOADER_BASE    0x100000
#define PRELOADER_ENTRY   0x10066C
#define SRAM_STACK_TOP    0x200000
#define DRAM_BASE         0x40000000
#define LK_BASE           0x48200000
#define UFS_BASE          0x10020000

// Register base addresses (MT6877)
#define UART0_BASE        0x11002000
#define UART1_BASE        0x11003000
#define UART2_BASE        0x11004000
#define UART3_BASE        0x11005000

#define GPT_BASE          0x10008000
#define EMMC_BASE         0x11230000
#define UFS_BASE_ADDR     0x11270000

#define WDT_BASE          0x10007000
#define TIMER_BASE        0x10004000
#define PMIC_WRAP_BASE    0x10006000

#define DRAMC_BASE        0x1022C000
#define DRAMC_CH0_BASE    0x1022E000
#define DRAMC_CH1_BASE    0x10230000

// Preloader status
typedef enum {
    BOOT_UNKNOWN = 0,
    BOOT_NORMAL,
    BOOT_RECOVERY,
    BOOT_META,
    BOOT_FASTBOOT,
    BOOT_USBDL,
} boot_mode_t;

// Image types
typedef enum {
    IMAGE_LK = 0,
    IMAGE_BOOT,
    IMAGE_RECOVERY,
    IMAGE_TEE,
    IMAGE_LOGO,
    IMAGE_DTBO,
    IMAGE_VBMETA,
} image_type_t;

// GFH types
#define GFH_TYPE_FILE_INFO  0
#define GFH_TYPE_BL_INFO    1
#define GFH_TYPE_ATTEST     2
#define GFH_TYPE_BL_SEC_KEY 7
#define GFH_TYPE_BL_LOAD    8
#define GFH_TYPE_BL_ATTR    18

#define GFH_MAGIC           0x014D4D4D

typedef struct __attribute__((packed)) {
    uint32_t magic;
    uint32_t size;
    uint32_t type;
    uint8_t  name[8];
    uint16_t version;
    uint16_t reserved;
    uint32_t flash_type;
    uint32_t load_block;
    uint32_t load_addr;
    uint32_t load_size;
    uint32_t entry;
    uint32_t region;
    uint32_t reserved2[2];
} gfh_file_info_t;

typedef struct __attribute__((packed)) {
    uint32_t version;
    uint32_t reserved;
    uint32_t project;
} gfh_bl_info_t;

typedef struct __attribute__((packed)) {
    uint8_t key_data[80];
    uint32_t key_length;
    uint8_t reserved[12];
} gfh_bl_sec_key_t;

typedef struct __attribute__((packed)) {
    uint32_t offset;
    uint32_t length;
    uint32_t dest_addr;
    uint32_t reserved;
} gfh_load_segment_t;

typedef struct __attribute__((packed)) {
    uint32_t type;
    uint32_t version;
    uint32_t flags;
} gfh_attr_t;

// GPT
typedef struct __attribute__((packed)) {
    uint64_t signature;
    uint32_t revision;
    uint32_t header_size;
    uint32_t crc32;
    uint32_t reserved;
    uint64_t current_lba;
    uint64_t backup_lba;
    uint64_t first_usable_lba;
    uint64_t last_usable_lba;
    uint8_t  guid[16];
    uint64_t entry_lba;
    uint32_t num_entries;
    uint32_t entry_size;
    uint32_t entry_crc32;
} gpt_header_t;

typedef struct __attribute__((packed)) {
    uint8_t  type_guid[16];
    uint8_t  part_guid[16];
    uint64_t first_lba;
    uint64_t last_lba;
    uint64_t attr_flags;
    uint16_t name[36];
} gpt_entry_t;

// MTK BR header (LK image)
#define BR_MAGIC1 0x58881688
#define BR_MAGIC2 0x58891689
#define BR_RAW    0x1

typedef struct __attribute__((packed)) {
    uint32_t magic1;
    uint32_t total_size;
    uint8_t  signature[8];
    uint8_t  reserved[0x20];
    uint32_t magic2;
    uint32_t load_addr;
    uint32_t flags;
    uint32_t reserved2;
    uint32_t entry_point;
    uint8_t  padding[0x1B8];
} br_header_t;

// Flash / Block device
#define BLOCK_SIZE 512

int flash_read_blocks(uint64_t lba, uint32_t count, uint8_t *buf);
void wdt_restart(void);
int boot_lk(void);

// Boot chain info passed to LK
typedef struct __attribute__((packed)) {
    uint32_t boot_reason;
    uint32_t boot_device;
    uint32_t reserved[2];
} boot_arg_t;

// Function prototypes
void preloader_main(void);
void arm_init(void);
void cache_ici_allu(uint32_t);
void cache_ici_allu_bic(uint32_t);

// Core functions
void uart_putc(char c);
void uart_puts(const char *s);
void uart_puthex(uint32_t val);
void uart_init(void);
void wdt_disable(void);
void timer_init(void);
int dram_init(void);
int gpt_parse(void);
int gpt_find_partition(const char *name, uint64_t *start_lba, uint64_t *size_lba);
int load_image_to_dram(const char *part_name, uint32_t load_addr);
void jump_to_lk(uint32_t entry, boot_arg_t *args);
int sha256_compute(const uint8_t *data, uint32_t len, uint8_t *hash);
int strcmp(const char *a, const char *b);
int memcmp(const void *a, const void *b, uint32_t n);
void *memcpy(void *dest, const void *src, uint32_t n);
void *memset(void *s, int c, uint32_t n);
int tolower(int c);
int strncasecmp(const char *a, const char *b, uint32_t n);

// printf-style
void printf(const char *fmt, ...);

#endif
