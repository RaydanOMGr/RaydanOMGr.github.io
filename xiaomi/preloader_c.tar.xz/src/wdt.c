#include "preloader.h"

#define WDT_MODE     0x00
#define WDT_LENGTH   0x04
#define WDT_RESTART  0x08
#define WDT_STATUS   0x0C

#define WDT_MODE_KEY     0x22000000
#define WDT_MODE_DISABLE  (1 << 0)
#define WDT_RESTART_KEY   0x1971

void wdt_disable(void)
{
    volatile uint32_t *wdt = (uint32_t *)WDT_BASE;
    wdt[WDT_MODE / 4] = WDT_MODE_KEY | WDT_MODE_DISABLE;
    wdt[WDT_RESTART / 4] = WDT_RESTART_KEY;
}

void wdt_restart(void)
{
    volatile uint32_t *wdt = (uint32_t *)WDT_BASE;
    wdt[WDT_RESTART / 4] = WDT_RESTART_KEY;
}
