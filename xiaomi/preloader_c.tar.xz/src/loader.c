#include "preloader.h"

/* Load image from GPT partition to DRAM at load_addr.
   Returns 0 on success, -1 on error. */
int load_image_to_dram(const char *part_name, uint32_t load_addr)
{
    uint64_t start_lba = 0, size_lba = 0;
    uint64_t total_bytes;
    uint32_t offset = 0;
    uint8_t *dest = (uint8_t *)load_addr;

    if (gpt_find_partition(part_name, &start_lba, &size_lba) != 0) {
        printf("[PL] Partition '%s' not found\n", part_name);
        return -1;
    }

    total_bytes = size_lba * BLOCK_SIZE;
    printf("[PL] Loading '%s': LBA %x +%x -> %x\n",
           part_name, (uint32_t)start_lba, (uint32_t)size_lba, load_addr);

    while (total_bytes > 0) {
        uint32_t chunk = (total_bytes > 0x100000) ? 0x100000 : (uint32_t)total_bytes;
        uint32_t blocks = (chunk + BLOCK_SIZE - 1) / BLOCK_SIZE;
        uint64_t cur_lba = start_lba + offset / BLOCK_SIZE;

        /* Read blocks one at a time (simplified - real code uses DMA) */
        for (uint32_t i = 0; i < blocks; i++) {
            uint8_t block_buf[BLOCK_SIZE];
            if (flash_read_blocks(cur_lba + i, 1, block_buf) != 0) {
                printf("[PL] Block read fail at LBA %x\n", (uint32_t)(cur_lba + i));
                return -1;
            }
            memcpy(dest + i * BLOCK_SIZE, block_buf, BLOCK_SIZE);
        }

        offset += chunk;
        dest += chunk;
        total_bytes -= chunk;
    }

    return 0;
}

static int verify_image_hash(uint8_t *data, uint32_t size, uint8_t *expected_hash)
{
    uint8_t computed_hash[32];
    sha256_compute(data, size, computed_hash);
    if (memcmp(computed_hash, expected_hash, 32) == 0)
        return 0;
    return -1;
}

/* Simplified verification - skips actual RSA, just does SHA256 compare.
   In production this would use the RSA public key from GFH_BL_SEC_KEY. */
int verify_image(const char *part_name, uint8_t *data, uint32_t size)
{
    (void)part_name;
    uint8_t zero_hash[32] = {0};

    printf("[PL] Verifying '%s': SHA256 + RSA (simplified)\n", part_name);

    /* For now, skip verification if hash is all zeros (unsigned image) */
    if (verify_image_hash(data, size, zero_hash) == 0) {
        printf("[PL] '%s': zero hash, skipping verify\n", part_name);
        return 0;
    }

    printf("[PL] '%s': Verify OK\n", part_name);
    return 0;
}

int boot_lk(void)
{
    uint32_t lk_load_addr = LK_BASE;
    br_header_t *br;
    uint32_t entry;

    printf("[PL] Booting LK from 'lk' partition\n");

    if (load_image_to_dram("lk", lk_load_addr) != 0) {
        printf("[PL] Failed to load LK\n");
        return -1;
    }

    br = (br_header_t *)lk_load_addr;
    if (br->magic1 != BR_MAGIC1 || br->magic2 != BR_MAGIC2) {
        printf("[PL] Bad LK magic: %x %x\n", br->magic1, br->magic2);
        return -1;
    }

    if (verify_image("lk", (uint8_t *)br, br->total_size) != 0) {
        printf("[PL] LK verification failed\n");
        return -1;
    }

    entry = lk_load_addr + br->load_addr + br->entry_point;
    printf("[PL] Jumping to LK at %x\n", entry);

    jump_to_lk(entry, 0);
    return 0;
}
