#include "preloader.h"

#define NUM_BLOCKS_TO_READ 2  // GPT header + partition entries in 2 blocks

/* Simple flash read abstraction - reads blocks from UFS/eMMC.
   This is a stub - real impl needs UFS/eMMC controller init + DMA. */
int flash_read_blocks(uint64_t lba, uint32_t count, uint8_t *buf)
{
    (void)lba; (void)count; (void)buf;
    if (buf) {}  /* suppress unused warning */
    /* TODO: Implement actual UFS/eMMC read.
       For MT6877, UFS controller at UFS_BASE. 
       Need: UFS PHY init, UniPro link startup, SCSI READ(10)/READ(16) commands. */
    return -1;
}

static gpt_header_t gpt_hdr;
static gpt_entry_t gpt_entries[128];
static int gpt_valid = 0;

int gpt_parse(void)
{
    uint8_t buf[BLOCK_SIZE];
    uint32_t i, num_entries, entry_size;
    uint64_t entry_lba;

    if (flash_read_blocks(1, 1, buf) != 0)
        return -1;
    memcpy(&gpt_hdr, buf, sizeof(gpt_hdr));

    if (gpt_hdr.signature != 0x5452415020494645ULL)
        return -1;

    entry_lba = gpt_hdr.entry_lba;
    num_entries = gpt_hdr.num_entries;
    entry_size = gpt_hdr.entry_size;

    if (num_entries > 128) num_entries = 128;

    for (i = 0; i < num_entries; i++) {
        uint64_t lba_offset = entry_lba + (i * entry_size) / BLOCK_SIZE;
        uint32_t byte_offset = (i * entry_size) % BLOCK_SIZE;

        if (flash_read_blocks(lba_offset, 1, buf) != 0)
            return -1;
        memcpy((uint8_t *)&gpt_entries[i] + byte_offset,
               buf + byte_offset,
               entry_size < sizeof(gpt_entry_t) ? entry_size : sizeof(gpt_entry_t));
    }

    gpt_valid = 1;
    return 0;
}

int gpt_find_partition(const char *name, uint64_t *start_lba, uint64_t *size_lba)
{
    uint32_t i;
    char pname[37];
    int j;

    if (!gpt_valid) return -1;

    for (i = 0; i < gpt_hdr.num_entries && i < 128; i++) {
        for (j = 0; j < 36 && gpt_entries[i].name[j]; j++)
            pname[j] = (char)gpt_entries[i].name[j];
        pname[j] = 0;

        if (strncasecmp(pname, name, 36) == 0) {
            *start_lba = gpt_entries[i].first_lba;
            *size_lba = gpt_entries[i].last_lba - gpt_entries[i].first_lba + 1;
            return 0;
        }
    }
    return -1;
}
