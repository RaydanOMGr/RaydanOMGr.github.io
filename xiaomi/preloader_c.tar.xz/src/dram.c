#include "preloader.h"

/* DRAM controller register offsets for MT6877 LPDDR4x */
#define DRAMC_SHU0          0x000
#define DRAMC_SHU1          0x100
#define DRAMC_SHU2          0x200
#define DRAMC_SHU3          0x300
#define DRAMC_ACTIM         0x400
#define DRAMC_DLR           0x500
#define DRAMC_DLE           0x504
#define DRAMC_MR            0x600
#define DRAMC_MRS           0x604
#define DRAMC_ZQCTL         0x700
#define DRAMC_PDCTL         0x800
#define DRAMC_REFCTL        0x900
#define DRAMC_SHUFFLE       0xA00
#define DRAMC_MISC          0xB00

#define DRAMC_SWCTL         0xC00
#define DRAMC_SWLVL         0xC04

/* PMIC register for DRAM voltage via SPI */
#define PMIC_WRAP_SRAMIOC   0x0A00
#define PMIC_WRAP_DRAM_VOLT 0x0A04
#define VDDQ_LPDDR4X        0x11  /* 1.1V */
#define VDD2_LPDDR4X        0x14  /* 1.05V? */

static void dramc_write(uint32_t base, uint32_t reg, uint32_t val)
{
    volatile uint32_t *addr = (uint32_t *)(base + reg);
    *addr = val;
}

static uint32_t dramc_read(uint32_t base, uint32_t reg)
{
    volatile uint32_t *addr = (uint32_t *)(base + reg);
    return *addr;
}

static void pmic_set_voltage(uint32_t reg, uint32_t val)
{
    volatile uint32_t *pmic = (uint32_t *)PMIC_WRAP_BASE;
    /* PMIC wrap protocol: write (reg << 8) | val to SRAMIOC */
    uint32_t cmd = (reg << 8) | (val & 0xFF);
    pmic[PMIC_WRAP_SRAMIOC / 4] = cmd;
    /* Wait for PMIC ready */
    for (volatile int i = 0; i < 1000; i++);
}

static void dram_phy_init(void)
{
    /* DRAM PHY initialization sequence for LPDDR4x on MT6877.
       Actual calibration values would come from BROM/CAL data. */

    /* Set VDDQ and VDD2 via PMIC */
    pmic_set_voltage(0x10, VDDQ_LPDDR4X);
    pmic_set_voltage(0x12, VDD2_LPDDR4X);

    /* Enable DRAM controller clock */
    /* TODO: Set DRAMC clock gate via APMIXED/CK_TOP */
}

static void dram_calibrate(void)
{
    /* Read training data from BROM calibration region or OTP.
       For minimal boot, we skip full calibration and use
       safe timing parameters. */

    /* Set default timing: CAS=16, RAS=28, CWL=14, WR=16 */
    dramc_write(DRAMC_BASE, DRAMC_ACTIM, 0x1C101E10);

    /* Set ZQ calibration */
    dramc_write(DRAMC_BASE, DRAMC_ZQCTL, 0x10000F0F);

    /* Write leveling - basic values */
    dramc_write(DRAMC_BASE, DRAMC_SWLVL, 0x00000001);

    /* DQS gate calibration */
    dramc_write(DRAMC_BASE, DRAMC_DLR, 0x00200020);
}

static void dram_init_controller(void)
{
    /* Initialize DRAM controller hardware */

    /* 1. Set DRAM type to LPDDR4x */
    dramc_write(DRAMC_BASE, DRAMC_MR, 0x00000000);

    /* 2. Configure MR registers for LPDDR4x:
          MR1: write leveling enable
          MR2: VREF training
          MR3: ODT configuration */
    dramc_write(DRAMC_BASE, DRAMC_MRS, 0x00000000);

    /* 3. Issue ZQ calibration start */
    dramc_write(DRAMC_BASE, DRAMC_ZQCTL, 0x00000001);
    for (volatile int i = 0; i < 5000; i++);

    /* 4. Enable controller */
    dramc_write(DRAMC_BASE, DRAMC_SWCTL, 0x00000001);

    /* 5. Wait for controller ready */
    for (volatile int i = 0; i < 10000; i++);
    while (!(dramc_read(DRAMC_BASE, DRAMC_SWCTL) & 2));
}

int dram_init(void)
{
    printf("[PL] DRAM init start\n");

    dram_phy_init();
    dram_calibrate();
    dram_init_controller();

    /* Quick memory test - write pattern, read back */
    volatile uint32_t *test = (uint32_t *)DRAM_BASE;
    *test = 0xDEADBEEF;
    if (*test != 0xDEADBEEF) {
        printf("[PL] DRAM init FAILED\n");
        return -1;
    }

    /* Test more addresses */
    test[0x1000] = 0xA55A5AA5;
    if (test[0x1000] != 0xA55A5AA5) {
        printf("[PL] DRAM range test FAILED\n");
        return -1;
    }

    printf("[PL] DRAM init OK: %dMB\n", /* TODO: calculate from regs */ 4096);
    return 0;
}
