#include "preloader.h"

#define UART_THR    0x00
#define UART_RBR    0x00
#define UART_DLL    0x00
#define UART_DLH    0x04
#define UART_IER    0x04
#define UART_FCR    0x08
#define UART_LCR    0x0C
#define UART_MCR    0x10
#define UART_LSR    0x14
#define UART_MSR    0x18
#define UART_USR    0x7C

#define LSR_THRE    (1 << 5)
#define LSR_TEMT    (1 << 6)

static volatile uint32_t *uart_base = (uint32_t *)UART0_BASE;

void uart_init(void)
{
    uint32_t lcr;

    lcr = uart_base[UART_LCR / 4];
    uart_base[UART_LCR / 4] = lcr | 0x80;
    uart_base[UART_DLL / 4] = 13;
    uart_base[UART_DLH / 4] = 0;
    uart_base[UART_LCR / 4] = lcr & ~0x80;
    uart_base[UART_LCR / 4] = 0x03;
    uart_base[UART_FCR / 4] = 0x07;
    uart_base[UART_MCR / 4] = 0x03;
}

void uart_putc(char c)
{
    if (c == '\n')
        uart_putc('\r');
    while (!(uart_base[UART_LSR / 4] & LSR_THRE));
    uart_base[UART_THR / 4] = c;
}

void uart_puts(const char *s)
{
    while (*s)
        uart_putc(*s++);
}

void uart_puthex(uint32_t val)
{
    char buf[11];
    int i;
    buf[0] = '0';
    buf[1] = 'x';
    for (i = 0; i < 8; i++) {
        int nib = (val >> (28 - i * 4)) & 0xF;
        buf[2 + i] = nib < 10 ? '0' + nib : 'a' + nib - 10;
    }
    buf[10] = 0;
    uart_puts(buf);
}
