#include "preloader.h"

int strcmp(const char *a, const char *b)
{
    while (*a && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}

int memcmp(const void *a, const void *b, uint32_t n)
{
    const unsigned char *pa = a, *pb = b;
    while (n--) {
        if (*pa != *pb) return *pa - *pb;
        pa++; pb++;
    }
    return 0;
}

void *memcpy(void *dest, const void *src, uint32_t n)
{
    unsigned char *d = dest;
    const unsigned char *s = src;
    while (n--) *d++ = *s++;
    return dest;
}

void *memset(void *s, int c, uint32_t n)
{
    unsigned char *p = s;
    while (n--) *p++ = (unsigned char)c;
    return s;
}

int tolower(int c)
{
    if (c >= 'A' && c <= 'Z') return c + 32;
    return c;
}

int strncasecmp(const char *a, const char *b, uint32_t n)
{
    while (n--) {
        int ca = tolower(*a++);
        int cb = tolower(*b++);
        if (ca != cb) return ca - cb;
        if (!ca) break;
    }
    return 0;
}
