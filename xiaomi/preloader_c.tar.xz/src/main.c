#include "preloader.h"

/* Hardware version detection */
static uint32_t get_hw_code(void)
{
    uint32_t midr;
    __asm__ volatile("mrc p15, 0, %0, c0, c0, 0" : "=r"(midr));
    return (midr >> 4) & 0xFFF;  /* Part number from MIDR */
}

/* Boot mode detection via hardware PMIC/GPIO register reads */
static boot_mode_t detect_boot_mode(void)
{
    volatile uint32_t *pmic = (uint32_t *)PMIC_WRAP_BASE;
    uint32_t pmic_status = pmic[0x100 / 4];

    if (pmic_status & 0x1)
        return BOOT_NORMAL;
    if (pmic_status & 0x2)
        return BOOT_RECOVERY;
    if (pmic_status & 0x4)
        return BOOT_META;
    return BOOT_NORMAL;
}

static void print_banner(void)
{
    printf("\n\n");
    printf("[PL] Mediatek Preloader (C port)\n");
    printf("[PL] SoC: MT%x\n", get_hw_code() == 0xD03 ? 6877 : 8791);
}

static void print_hw_config(void)
{
    uint32_t midr, ctr, clidr;

    __asm__ volatile("mrc p15, 0, %0, c0, c0, 0" : "=r"(midr));
    __asm__ volatile("mrc p15, 0, %0, c0, c0, 1" : "=r"(ctr));
    __asm__ volatile("mrc p15, 1, %0, c0, c0, 1" : "=r"(clidr));

    printf("[PL] MIDR: %x  CTR: %x  CLIDR: %x\n", midr, ctr, clidr);
}

void preloader_main(void)
{
    boot_mode_t mode;
    int ret;

    /* 1. Disable watchdog */
    wdt_disable();

    /* 2. Initialize UART for debug output */
    uart_init();
    timer_init();

    print_banner();
    print_hw_config();

    /* 3. Initialize DRAM */
    ret = dram_init();
    if (ret != 0) {
        printf("[PL] DRAM init failed, entering USBDL mode\n");
        goto usbdl_fallback;
    }

    /* 4. Detect boot mode */
    mode = detect_boot_mode();
    printf("[PL] Boot mode: %d\n", mode);

    /* 5. Parse GPT partition table */
    ret = gpt_parse();
    if (ret != 0) {
        printf("[PL] GPT parse failed (may need flash init)\n");
    } else {
        printf("[PL] GPT parsed successfully\n");
    }

    /* 6. Load and boot LK */
    printf("[PL] Booting LK...\n");
    ret = boot_lk();
    if (ret != 0) {
        printf("[PL] LK boot failed, trying USB fallback\n");
        goto usbdl_fallback;
    }

usbdl_fallback:
    printf("[PL] Entering USB download mode\n");
    printf("[PL] Waiting for DA...\n");

    /* Enter infinite loop - USBDL would be implemented here */
    while (1) {
        wdt_restart();
        __asm__ volatile("wfi");
    }
}
