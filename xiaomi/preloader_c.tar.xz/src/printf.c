#include <stdarg.h>
#include "preloader.h"

void printf(const char *fmt, ...)
{
    const char *p;
    uint32_t val;
    int i;
    va_list args;
    va_start(args, fmt);

    for (p = fmt; *p; p++) {
        if (*p != '%') {
            uart_putc(*p);
            continue;
        }
        p++;
        switch (*p) {
        case 'd': {
            int sval = va_arg(args, int);
            if (sval < 0) { uart_putc('-'); sval = -sval; }
            val = sval;
            goto print_dec;
        }
        case 'u':
            val = va_arg(args, uint32_t);
print_dec: {
            char dbuf[12];
            int di = 0;
            if (val == 0) { dbuf[di++] = '0'; }
            else { while (val) { dbuf[di++] = '0' + (val % 10); val /= 10; } }
            for (i = di - 1; i >= 0; i--) uart_putc(dbuf[i]);
            break;
        }
        case 'x':
            val = va_arg(args, uint32_t);
            for (i = 7; i >= 0; i--) {
                int nib = (val >> (i * 4)) & 0xF;
                uart_putc(nib < 10 ? '0' + nib : 'a' + nib - 10);
            }
            break;
        case 's':
            uart_puts(va_arg(args, const char *));
            break;
        case 'c':
            uart_putc(va_arg(args, int));
            break;
        case 'l': {
            if (*(p+1) == 'l') { p++; }
            if (*(p+1) == 'x') { p++; val = va_arg(args, uint32_t); goto print_hex; }
            if (*(p+1) == 'u') { p++; val = va_arg(args, uint32_t); goto print_dec; }
            if (*(p+1) == 'd') { p++; val = va_arg(args, int); goto print_dec; }
            break;
        }
        default:
            uart_putc(*p);
            break;
        }
    }
    va_end(args);
    return;
print_hex:
    for (i = 7; i >= 0; i--) {
        int nib = (val >> (i * 4)) & 0xF;
        uart_putc(nib < 10 ? '0' + nib : 'a' + nib - 10);
    }
}
