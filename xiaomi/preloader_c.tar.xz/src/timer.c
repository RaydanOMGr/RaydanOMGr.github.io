#include "preloader.h"

#define TIMER_CON     0x00
#define TIMER_CLK     0x04
#define TIMER_CNT     0x08
#define TIMER_CMP     0x0C
#define TIMER_IRQ_EN  0x18
#define TIMER_IRQ_STA 0x1C

#define TIMER_CON_EN  (1 << 0)
#define TIMER_CON_IRQ (1 << 1)

static volatile uint32_t *timer = (uint32_t *)TIMER_BASE;

void timer_init(void)
{
    timer[TIMER_CON / 4] = 0;
    timer[TIMER_CLK / 4] = 13000000;
    timer[TIMER_CON / 4] = TIMER_CON_EN;
}

uint32_t timer_get_us(void)
{
    return timer[TIMER_CNT / 4] / 13;
}

void timer_delay_us(uint32_t us)
{
    uint32_t start = timer[TIMER_CNT / 4];
    uint32_t ticks = us * 13;
    while ((timer[TIMER_CNT / 4] - start) < ticks);
}

void timer_delay_ms(uint32_t ms)
{
    timer_delay_us(ms * 1000);
}
