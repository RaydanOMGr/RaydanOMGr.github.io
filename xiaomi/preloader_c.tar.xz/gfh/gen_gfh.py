#!/usr/bin/env python3
"""Generate GFH header binary matching MTK preloader format (256 bytes)."""
import struct

def gen_gfh():
    data = bytearray()

    def gfh_entry(type_, size, body):
        data.extend(b"MMM\x01")
        data.extend(struct.pack("<I", size))
        data.extend(struct.pack("<I", type_))
        data.extend(body)

    # GFH_FILE_INFO at 0x00, type=0, size=56
    # body: name(8) + ver(2) + rsv(2) + 8 words(32) = 44 bytes
    body = b"FILE_INFO\x00"          # name[8]
    body += struct.pack("<HH", 1, 0)  # version=1, reserved=0
    body += struct.pack("<II", 0x050E0001, 0x00200F00)
    body += struct.pack("<II", 0x100000, 0x736B4)
    body += struct.pack("<II", 0x100, 1)  # image_type=0x100, load_mode=1
    body += struct.pack("<I", 0x66C)       # entry offset
    body += struct.pack("<I", 0x00010000)  # reserved
    body += struct.pack("<I", 0x00010000)  # reserved
    gfh_entry(0, 56, body)
    assert len(data) == 56, f"FILE_INFO size: {len(data)}"

    # GFH_BL_INFO at 0x38, type=1, size=12 (header only, no body)
    gfh_entry(1, 12, b"")
    assert len(data) == 68

    # GFH_BL_SEC_KEY at 0x44, type=7, size=100
    body = b"\x00" * 80
    body += struct.pack("<I", 0x1388)
    body += b"\x00" * 12
    gfh_entry(7, 100, body)
    assert len(data) == 168

    # GFH_ATTEST at 0xA8, type=2, size=20
    gfh_entry(2, 20, b"\x00" * 12)
    assert len(data) == 188

    # GFH_BL_LOAD at 0xBC, type=8, size=48
    gfh_entry(8, 48, b"\x00" * 40)
    assert len(data) == 236

    # GFH_BL_ATTR at 0xEC, type=18, size=20
    gfh_entry(18, 20, b"\x00" * 12)

    # Pad to exactly 256 bytes
    assert len(data) <= 256
    if len(data) < 256:
        data += b"\x00" * (256 - len(data))
    assert len(data) == 256

    with open("gfh_header.bin", "wb") as f:
        f.write(data)
    print(f"GFH header: {len(data)} bytes")

if __name__ == "__main__":
    gen_gfh()
